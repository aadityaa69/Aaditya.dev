import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { ArrowUpRight, Camera, Code2, Gamepad2, Mail, MessageCircle, Sparkles } from "lucide-react";
import { Header } from "@/components/Header";
import { ProjectCard } from "@/components/ProjectCard";
import { projects, skills } from "@/data/projects";
import avatarImg from "@/assets/avatar.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aaditya's Portfolio — Game Developer" },
      {
        name: "description",
        content: "Aaditya Yadav — indie game developer working in Unity, Unreal & Godot.",
      },
      { property: "og:title", content: "Aaditya's Portfolio" },
      { property: "og:description", content: "Indie game developer portfolio." },
    ],
  }),
  component: Index,
});

const schema = z.object({
  name: z.string().trim().min(1, "Required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  message: z.string().trim().min(10, "A bit more please").max(1000),
});

const socials = [
  { label: "Instagram", handle: "@aadityamakesgames", href: "https://instagram.com", Icon: Camera },
  { label: "Discord", handle: "aaditya#0001", href: "https://discord.com", Icon: MessageCircle },
  { label: "itch.io", handle: "aaditya.itch.io", href: "https://itch.io", Icon: Gamepad2 },
  { label: "GitHub", handle: "aadityayadav", href: "https://github.com", Icon: Code2 },
  { label: "Email", handle: "hello@aaditya.dev", href: "mailto:hello@aaditya.dev", Icon: Mail },
];

const timeline = [
  { year: "2025", text: "Started Deep Signal — sonar-based horror." },
  { year: "2024", text: "Shipped Neon Drift on Steam." },
  { year: "2023", text: "Won Ludum Dare 54." },
  { year: "2021", text: "Went full-time indie." },
  { year: "2019", text: "Wrote my first shader." },
];

function Index() {
  const shipped = projects.filter((p) => p.status === "shipped");
  const upcoming = projects.filter((p) => p.status !== "shipped");

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 pt-8">
        <Hero />
        <ProjectsSection shipped={shipped} />
        <UpcomingSection upcoming={upcoming} />
        <AboutSection />
        <SkillsTimeline />
        <ContactSection />
      </main>
    </div>
  );
}

function Hero() {
  return (
    <section id="home" className="max-w-5xl mx-auto px-6 pt-16 pb-20 scroll-mt-28">
      <div className="grid md:grid-cols-[1fr_auto] gap-10 items-center">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 mb-6 text-xs font-medium border-2 border-foreground rounded-full bg-accent text-accent-foreground">
            <Sparkles size={12} /> Open for collabs — 2025
          </div>
          <h1 className="font-serif text-5xl md:text-6xl font-bold leading-[1.05] mb-6">
            Hey, I'm Aaditya. I make games.
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mb-8 leading-relaxed">
            Indie dev building tight loops, weird mechanics, and shaders that go <em>woosh</em> — in Unity, Unreal & Godot.
          </p>
          <div className="flex flex-wrap gap-3">
            <a
              href="#projects"
              className="px-5 py-2.5 bg-foreground text-background font-medium rounded-full border-2 border-foreground shadow-brutal shadow-brutal-hover"
            >
              See my work →
            </a>
            <a
              href="#contact"
              className="px-5 py-2.5 bg-card text-foreground font-medium rounded-full border-2 border-foreground shadow-brutal shadow-brutal-hover"
            >
              Get in touch
            </a>
          </div>
        </div>

        <div className="relative justify-self-center md:justify-self-end">
          <div className="absolute -inset-2 bg-accent rounded-full -z-10 blur-2xl opacity-50" />
          <img
            src={avatarImg}
            alt="Aaditya Yadav"
            width={220}
            height={220}
            className="w-44 h-44 md:w-56 md:h-56 rounded-full border-2 border-foreground object-cover shadow-brutal-lg"
          />
          <div className="absolute -bottom-2 -right-2 px-3 py-1 bg-card border-2 border-foreground rounded-full text-xs font-medium shadow-brutal">
            👋 hi!
          </div>
        </div>
      </div>

      <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          ["6+", "Years"],
          ["12", "Shipped"],
          ["3", "Jam wins"],
          ["1", "Cat"],
        ].map(([n, l]) => (
          <div
            key={l}
            className="border-2 border-foreground rounded-2xl bg-card p-4 shadow-brutal"
          >
            <div className="font-serif text-3xl font-bold">{n}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ProjectsSection({ shipped }: { shipped: typeof projects }) {
  return (
    <section id="projects" className="max-w-5xl mx-auto px-6 py-16 scroll-mt-28">
      <SectionHeader eyebrow="01 — Work" title="Shipped" />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shipped.map((p) => (
          <ProjectCard key={p.slug} project={p} />
        ))}
      </div>
    </section>
  );
}

function UpcomingSection({ upcoming }: { upcoming: typeof projects }) {
  return (
    <section id="upcoming" className="max-w-5xl mx-auto px-6 py-16 scroll-mt-28">
      <SectionHeader eyebrow="02 — Workbench" title="Upcoming" />
      <div className="grid md:grid-cols-2 gap-6">
        {upcoming.map((p) => (
          <ProjectCard key={p.slug} project={p} />
        ))}
      </div>
    </section>
  );
}

function AboutSection() {
  return (
    <section id="about" className="max-w-5xl mx-auto px-6 py-16 scroll-mt-28">
      <SectionHeader eyebrow="03 — About" title="About me" />
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4 text-foreground/90 leading-relaxed">
          <p>
            Solo game dev, six years in. Started by modding RPG Maker, never stopped.
            Comfortable across <span className="font-medium">Unity</span>,{" "}
            <span className="font-medium">Unreal</span>, and{" "}
            <span className="font-medium">Godot</span>.
          </p>
          <p>
            Off-hours: CRT games and staring contests with my cat.
          </p>
        </div>
        <div className="border-2 border-foreground rounded-2xl p-5 bg-accent text-accent-foreground shadow-brutal h-fit">
          <div className="text-xs uppercase tracking-wider mb-2">Currently</div>
          <p className="font-serif text-xl font-bold mb-2">Deep Signal</p>
          <p className="text-sm opacity-80">Sonar-only submarine horror. 2026.</p>
        </div>
      </div>
    </section>
  );
}

function SkillsTimeline() {
  return (
    <section className="max-w-5xl mx-auto px-6 py-16">
      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <h3 className="font-serif text-3xl font-bold mb-6">Skills</h3>
          <div className="grid gap-3">
            {skills.map((s) => (
              <div
                key={s.name}
                className="flex items-center justify-between border-2 border-foreground rounded-xl px-4 py-3 bg-card"
              >
                <span className="font-medium">{s.name}</span>
                <span className="text-xs px-2 py-0.5 bg-accent text-accent-foreground rounded-full">
                  {s.level}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="font-serif text-3xl font-bold mb-6">Timeline</h3>
          <ol className="border-l-2 border-foreground pl-6 space-y-5">
            {timeline.map((t) => (
              <li key={t.year} className="relative">
                <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-accent border-2 border-foreground" />
                <div className="font-serif text-xl font-bold">{t.year}</div>
                <p className="text-muted-foreground text-sm">{t.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => {
        if (i.path[0]) errs[i.path[0] as string] = i.message;
      });
      setErrors(errs);
      return;
    }
    setErrors({});
    setSent(true);
  };

  return (
    <section id="contact" className="max-w-5xl mx-auto px-6 py-16 scroll-mt-28">
      <SectionHeader eyebrow="04 — Contact" title="Say hi" />
      <div className="grid md:grid-cols-5 gap-8">
        <div className="md:col-span-3">
          {sent ? (
            <div className="border-2 border-foreground rounded-2xl p-8 bg-accent text-accent-foreground shadow-brutal text-center">
              <Sparkles className="mx-auto mb-3" size={32} />
              <h3 className="font-serif text-2xl font-bold mb-2">Message sent!</h3>
              <p className="opacity-80">Talk soon.</p>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-4">
              <Field label="Name" error={errors.name}>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2.5 border-2 border-foreground rounded-xl bg-card text-foreground focus:outline-none focus:shadow-brutal transition-shadow"
                  placeholder="Your name"
                  maxLength={100}
                />
              </Field>
              <Field label="Email" error={errors.email}>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full px-3 py-2.5 border-2 border-foreground rounded-xl bg-card text-foreground focus:outline-none focus:shadow-brutal transition-shadow"
                  placeholder="you@studio.com"
                  maxLength={255}
                />
              </Field>
              <Field label="Message" error={errors.message}>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  rows={5}
                  className="w-full px-3 py-2.5 border-2 border-foreground rounded-xl bg-card text-foreground focus:outline-none focus:shadow-brutal transition-shadow resize-none"
                  placeholder="What's on your mind?"
                  maxLength={1000}
                />
              </Field>
              <button
                type="submit"
                className="px-6 py-3 bg-foreground text-background font-medium rounded-full border-2 border-foreground shadow-brutal shadow-brutal-hover"
              >
                Send →
              </button>
            </form>
          )}
        </div>

        <aside className="md:col-span-2 space-y-3">
          <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">
            Elsewhere
          </div>
          {socials.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noreferrer noopener"
              className="flex items-center gap-3 border-2 border-foreground rounded-xl px-4 py-3 bg-card shadow-brutal-hover group"
            >
              <span className="flex items-center justify-center w-9 h-9 rounded-lg bg-accent text-accent-foreground border-2 border-foreground">
                <s.Icon size={16} />
              </span>
              <span className="flex-1">
                <span className="block font-medium text-sm">{s.label}</span>
                <span className="block text-xs text-muted-foreground">{s.handle}</span>
              </span>
              <ArrowUpRight size={16} className="text-muted-foreground group-hover:text-foreground transition-colors" />
            </a>
          ))}
        </aside>
      </div>
    </section>
  );
}

function SectionHeader({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-8">
      <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">
        {eyebrow}
      </div>
      <h2 className="font-serif text-4xl font-bold">{title}</h2>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-sm font-medium">{label}</span>
        {error && <span className="text-xs text-destructive">{error}</span>}
      </div>
      {children}
    </label>
  );
}
