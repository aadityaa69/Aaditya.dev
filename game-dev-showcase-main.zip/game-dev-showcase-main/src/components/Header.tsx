import { useEffect, useState } from "react";
import { FileText } from "lucide-react";
import avatarImg from "@/assets/avatar.jpg";

const links = [
  { id: "home", label: "Home" },
  { id: "projects", label: "Projects" },
  { id: "upcoming", label: "Upcoming" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
];

export function Header() {
  const [active, setActive] = useState("home");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      const scrollY = window.scrollY + window.innerHeight / 2;
      let current = "home";
      for (const l of links) {
        const el = document.getElementById(l.id);
        if (el && el.offsetTop <= scrollY) current = l.id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header className="sticky top-4 z-50 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between bg-card/90 backdrop-blur-md border-2 border-foreground rounded-full pl-2 pr-2 py-1.5 shadow-brutal">
          <button
            onClick={() => go("home")}
            className="flex items-center gap-2 pr-2"
          >
            <img
              src={avatarImg}
              alt="Aaditya"
              width={36}
              height={36}
              className="w-9 h-9 rounded-full border-2 border-foreground object-cover"
            />
            <span className="font-serif text-lg font-bold tracking-tight hidden sm:inline">
              aaditya<span className="text-accent">.</span>
            </span>
          </button>

          <nav className="hidden md:flex items-center gap-1 text-sm">
            {links.map((l) => (
              <button
                key={l.id}
                onClick={() => go(l.id)}
                className={`px-3 py-1.5 rounded-full transition-colors ${
                  active === l.id
                    ? "bg-foreground text-background"
                    : "hover:bg-secondary"
                }`}
              >
                {l.label}
              </button>
            ))}
          </nav>

          <a
            href="/resume.pdf"
            target="_blank"
            rel="noreferrer noopener"
            className="hidden md:inline-flex items-center gap-1.5 px-4 py-1.5 text-sm bg-accent text-accent-foreground border-2 border-foreground rounded-full font-medium"
          >
            <FileText size={14} /> Resume
          </a>

          <button
            onClick={() => setOpen((v) => !v)}
            className="md:hidden p-2 rounded-full hover:bg-secondary"
            aria-label="Menu"
          >
            <div className="w-5 flex flex-col gap-1">
              <span className={`h-0.5 bg-foreground transition-transform ${open ? "translate-y-1.5 rotate-45" : ""}`} />
              <span className={`h-0.5 bg-foreground transition-opacity ${open ? "opacity-0" : ""}`} />
              <span className={`h-0.5 bg-foreground transition-transform ${open ? "-translate-y-1.5 -rotate-45" : ""}`} />
            </div>
          </button>
        </div>

        {open && (
          <div className="md:hidden mt-2 bg-card border-2 border-foreground rounded-2xl p-2 shadow-brutal">
            {links.map((l) => (
              <button
                key={l.id}
                onClick={() => go(l.id)}
                className={`block w-full text-left px-4 py-2 rounded-xl text-sm ${
                  active === l.id ? "bg-foreground text-background" : "hover:bg-secondary"
                }`}
              >
                {l.label}
              </button>
            ))}
            <a
              href="/resume.pdf"
              target="_blank"
              rel="noreferrer noopener"
              className="flex items-center gap-1.5 px-4 py-2 mt-1 text-sm bg-accent text-accent-foreground rounded-xl font-medium"
            >
              <FileText size={14} /> Resume
            </a>
          </div>
        )}
      </div>
    </header>
  );
}
